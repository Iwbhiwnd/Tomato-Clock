# Tomato-Clock
A pomodoro timer based on Python, works in Windows.
